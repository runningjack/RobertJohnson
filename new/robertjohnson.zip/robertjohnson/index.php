<?php
	require 'admin/libs/Controller.php';
	require 'libs/Bootstrap.php';
	require 'admin/libs/View.php';
	require 'admin/libs/Model.php';
	require "admin/libs/Database.php";
	require 'admin/libs/Session.php';
	require 'admin/libs/Admin.php';
	require 'admin/libs/Pages.php';
	require 'admin/libs/functions.php';
	require 'admin/libs/Contact.php';
	require 'admin/libs/RJ_News.php';
	require 'admin/libs/Category.php';
	require 'admin/libs/Product.php';


	require 'admin/config.php';


	$app = new Bootstrap();

	
?>

