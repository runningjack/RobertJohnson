<?php
class Model{
	public $registry;
	function __construct(){
		global $database;
		//$this->registry = $registry;
	}
}
?>