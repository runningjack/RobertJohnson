<?php
require_once('session.php');

// load config file first
//require_once('config.php');
require_once('database.php');
require_once('functions.php');
require_once('menu.php');
require_once('page.php');
?>