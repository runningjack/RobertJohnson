<?php

require_once(DIR_SYSTEM. "library/config.php");
require_once(DIR_SYSTEM. "library/database.php");
require_once(DIR_SYSTEM. "library/user.php");
require_once(DIR_SYSTEM. "library/session.php");
require_once(DIR_SYSTEM. "library/controller.php");
require_once(DIR_SYSTEM. "library/model.php");
require_once(DIR_SYSTEM. "library/registry.php");
require_once(DIR_SYSTEM. "library/view.php");
require_once(DIR_SYSTEM. "library/functions.php");
require_once(DIR_SYSTEM. "library/url.php");
require_once(DIR_SYSTEM. "library/menu.php");
require_once(DIR_SYSTEM. "library/page.php");
require_once(DIR_SYSTEM. "library/imageresize.php");
require_once(DIR_SYSTEM. "library/bootstrap.php");
require_once(DIR_SYSTEM. "library/news.php");
require_once(DIR_SYSTEM. "library/roles.php");
require_once(DIR_SYSTEM. "library/mailtemplate.php");
require_once(DIR_SYSTEM. "library/mail.php");
require_once(DIR_SYSTEM. "library/pagination.php");
require_once(DIR_SYSTEM. "library/priviledges.php");


