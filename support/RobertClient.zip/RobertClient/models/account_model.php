<?php
class Account_Model extends Model{
    function __construct(){
		parent::__construct();
	}
    
    public function getById($id){
		return Client::find_by_id($id);
       // $myaccount = Accounts::find_by_phone($phone);
       
	}
    
    public function getData(){
		global $database;
		$depts 			= Department::find_all();
		$role			= Roles::find_all();
		$country 		= Country::find_all();
        $vendors 		= Vendor::find_all();
        $countAcc       = count(Cproduct::find_by_client($_SESSION["client_ident"]));
        $schedule       =  Cproduct::getNextSchedule($_SESSION["client_ident"]);
        $countTic       = count(Ticket::find_by_client($_SESSION['client_ident']));
		$zone 			= Zone::find_by_sql("SELECT * FROM zone");
		$startups 		= array("departs"=>$depts,"country"=>$country,"zone"=>$zone,"vendors"=>$vendors,"role"=>$role,"countProd"=>$countAcc,"countTick"=>$countTic,"Schel"=>$schedule);
		return $startups;		
	}
    
    
    public function update()
    {
        if( !empty($_POST['cname']) && !empty($_POST['cphone']) && !empty($_POST['cemail'])){
            $thisClient                     =   Client::find_by_id((int)preg_replace('#[^0-9]#i','',$_SESSION['client_ident']));
        
            $thisClient->contact_phone          =       $_POST["cphone"];
            $thisClient->contact_email          =       $_POST["cemail"];
            $thisClient->contact_name           =       $_POST["cname"];
        	            
            
            if($thisClient->update()){
                return 1;
            }else{
                  return 2;
            }
        }else{
            return 3;
        }
        /**
         * Section to update password
         * for client
         */
        if( !empty($_POST['opword']) && !empty($_POST['uname']) && !empty($_POST['pword'])){
            $thisClient                     =   Client::find_by_id((int)preg_replace('#[^0-9]#i','',$_SESSION['client_ident']));
            if($thisClient->password !=$_POST["pword"]){
                echo "<div data-alert class='alert-box error'>Old Password is Incorrect <a href='#' class='close'>&times;</a></div>";
                exit;
            }
            if($_POST["pword2"] !=$_POST["pword"]){
                echo "<div data-alert class='alert-box error'>password mismatch please enter the same password for the password re-enter field as in the new password field <a href='#' class='close'>&times;</a></div>";
                exit;
            }
            $thisClient->username          =       $_POST["uname"];
            $thisClient->password          =       $_POST["pword"];
                     
            
            if($thisClient->update()){
                return 1;
            }else{
                  return 2;
            }
        }else{
            return 3;
        }
    }
}
?>