<?php
class Supportticket_Model extends Model{
	function __construct(){
		parent::__construct();
		
	}
	
	
	public function getList($id="",$pg){
		 $purl = array();
		if(isset($_GET['url'])){
			
			$purl	=	$_GET['url'];
			$purl	=	rtrim($purl);
			$purl	=	explode('/',$_GET['url']);
			
			
		}else{
			$purl =null;	
		}
		if(!isset($purl['2'])){
			$pn = 1;
		}else{
		$pn = $purl['2'];
		}
		global $database;
		$resultEmployee = $database->db_query("SELECT * FROM support_ticket");
		$pagin = new Pagination();//create the pagination object;
		$pagin->nr  = $database->dbNumRows($resultEmployee);
		$pagin->itemsPerPage = 20;
		
		$myitems = Ticket::find_by_sql("SELECT * FROM support_ticket ".$pagin->pgLimit($pn));
		
			$index_array =array( "Supportticket"=>$myitems,
							"mypagin"=>$pagin->render($pg));
							return $index_array;
		
		return $index_array;
	}
    
    
    	public function getListClient($id="",$pg){
		 $purl = array();
		if(isset($_GET['url'])){
			
			$purl	=	$_GET['url'];
			$purl	=	rtrim($purl);
			$purl	=	explode('/',$_GET['url']);
			
			
		}else{
			$purl =null;	
		}
		if(!isset($purl['2'])){
			$pn = 1;
		}else{
		$pn = $purl['2'];
		}
		global $database;
		$resultEmployee = $database->db_query("SELECT * FROM support_ticket WHERE client_id='".$_SESSION["client_ident"]."'");
		$pagin = new Pagination();//create the pagination object;
		$pagin->nr  = $database->dbNumRows($resultEmployee);
		$pagin->itemsPerPage = 20;
		
		$myitems = Ticket::find_by_sql("SELECT * FROM support_ticket WHERE client_id ='".$_SESSION["client_ident"]."' ".$pagin->pgLimit($pn));
		
			$index_array =array( "Supportticket"=>$myitems,
							"mypagin"=>$pagin->render($pg));
							return $index_array;
		
		return $index_array;
	}
	
	public function getById($id){
		return Ticket::find_by_id($id);
       // $myaccount = Accounts::find_by_phone($phone);
	}
	
	/**
     * load initail data for employee form needed during 
     * creating and editing employee
     * data 
     */
    
	public function getData(){
		global $database;
		$depts 			= Department::find_all();
		$role			= Roles::find_all();
		$country 		= Country::find_all();
        $vendors 		= Vendor::find_all();
		$myproducts		= Cproduct::find_by_client($_SESSION['client_ident']);
		$zone 			= Zone::find_by_sql("SELECT * FROM zone");
		$startups 		= array("departs"=>$depts,"country"=>$country,"zone"=>$zone,"vendors"=>$vendors,"role"=>$role,"myproducts"=>$myproducts);
		return $startups;		
	}
    
    public function getTicketData($id=""){
        $replies        =  Ticketreply::find_by_ticket($id);
        $ticket         =   Ticket::find_by_id($id);
        $tickdata       =   array("ticket"=>$ticket,"replies"=>$replies);
        return $tickdata;
    }
	
	
	public function create(){
		//if( !empty($_POST["issue"]) ){
		$newticket = new Ticket();
			if(isset($_FILES['fupload']) && $_FILES['fupload']['error']==0){ //if file upload is set
					move_uploaded_file($_FILES['fupload']['tmp_name'],"public/uploads/".basename($_FILES['fupload']['name']));
					$image = new Imageresize(); // an instance of image resize object
					$image->load("public/uploads/".basename($_FILES['fupload']['name']));
					//$image->image =;
					$image->resize(400,400);
					$image->save("public/uploads/".basename($_FILES['fupload']['name']));
					
					//this section is needed to get the extension for image type in renaming the image
					if ($_FILES['fupload']['type']=="image/gif"){
						$ext = ".gif";
					}
					if ($_FILES['fupload']['type']=="image/png"){
						$ext = ".png";
					}
					if ($_FILES['fupload']['type']=="image/jpeg"){
						$ext = ".jpeg";
					}
					if ($_FILES['fupload']['type']=="image/pjpeg"){
						$ext = ".jpeg";
					}
					if ($_FILES['fupload']['type']=="image/gif"){
						$ext = ".gif";
					}
					if ($_FILES['fupload']['type']=="image/jpg"){
						$ext = ".jpg";
					}
					$new_name = uniqid()."_".time().$ext; //new name for the image
					rename("public/uploads/".basename($_FILES['fupload']['name']),"public/uploads/".$new_name);
					$photo = $new_name;
					$newticket->file = $photo;
					  
				}else{
					//$applicant->img_url = $_POST['imgvalue'];
				}
                

                $cid = explode("_",$_POST["service"]);
               
                $newticket->contact_name                    =   $_POST["cname"];
                $newticket->contact_email                   =   $_POST["email"];
                $newticket->contact_phone                    =   $_POST["phone"];
                $newticket->prod_id                         =   $cid[0];
                $newticket->prod_name                       =   $cid[1];
                //$newticket->location;
                $newticket->priority                        =   $_POST["plevel"];
            	$newticket->subject                         =   $_POST['subject'];
                $newticket->department                      =   $_POST["dept"];
                $newticket->issue                           =   $_POST["issue"];
                $newticket->datecreated                     =	date("Y-m-d H:i:s");
                $newticket->status                          =   "Open";                   
                $newticket->client_id                       =   $_SESSION["client_ident"];
				
              	    
			
			if($newticket->create()){
			 
				return 1;     //returns 1 on success                        
			}else{
			 return 2;       // returns 2 on insert error
			}
			
			
		#}else{
#		  return 3; //returns 3 if requiered input field is not supplied
#		}
	}
    /**
     * function to handle client 
     * reply to a ticket
     */
    public function createClientReply($id=""){
        if(!empty($_POST["issue"]) && !empty($_POST["cname"])){
            $newReply = new Ticketreply();
            $newReply->sender_id        =       $_SESSION["client_ident"];
            $newReply->ticket_id        =       $id;
            $theCustomer                =       Client::find_by_id($_SESSION["client_ident"]);
            $newReply->sender_name      =       $theCustomer->name;
            $newReply->sender_type      =       "Client";
            $newReply->message          =       $_POST['issue'];
            $newReply->datecreated      =       date("Y-m-d H:i:s");
            if($newReply->create()){
                $partTicket = Ticket::find_by_id($id);
                $partTicket->status ="Customer Reply";
                $partTicket->datemodified = date("Y-m-d H:i:s");
                $partTicket->update();
                return 1;
            }else{
                return 2;
            }
        }else{
            return 3;
        }
    }
    /**
     * method to close a ticket
     * 
     */
     
     public function closeTicket(){
        if(isset($_POST['id']) && !empty($_POST["id"])){
            $partTicket = Ticket::find_by_id($_POST["id"]);
            $partTicket->status     =   "Closed";
            
            if($partTicket->update()){
                return true;
            }else{
                return false;
            }
        }
     }
 
}
?>