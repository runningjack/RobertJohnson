<div id="main">
		<div class="wrapper">
			<div class="container">
				
				
<div class="heading"><h2>My Tickets </h2>
					<div class="button">
						<ul>
							<li><a href="#"></a></li>
						</ul>
					</div>
				</div><!--button-->

				<!--<div class="success">Added Successfully</div>
				<div class="error">Error Adding</div>-->
                
				<?php echo $this->myservs; ?>
	     
			</div><!--container-->
		</div><!--wrapper-->
</div><!--main--