<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="initial-scale=1.0, width=device-width" />
<link href="public/css/style2.css" rel="stylesheet" type="text/css"/>
<style>
	@import url("public/css/resp.css") all and (max-width: 640px);
</style>
<title>Robert Johnson Holdings</title>
</head>

<body>
	<div id="header">
		<div class="wrapper">
			<img src="public/images/logo_2.png"/>

			<div class="right">
				<!--welcome-->

			</div><!--right-->
		</div><!--wrapper-->
	</div><!--header-->

	<div id="menu">
		<div class="wrapper">
			<!--<ul>
				<li><a href="#">Home</a></li>
				<li><a href="#">About Us</a></li>
				<li><a href="#">Product &amp; Services</a></li>
				<li><a href="#">Partners</a></li>
				<li><a href="#">Careers</a></li>
				<li><a href="#">Log Out</a></li>
			</ul>-->
		</div><!--wrapper-->
	</div><!--menu-->
       
    <div class="wrapper">
    	<div class="col-12">
    	<form action="" id="frmLogin" name="frmLogin" method="post" >
        	<fieldset>
                <legend><h2>Client Login</h2></legend><div id="alertme"><?php echo $this->msg ?></div>
            	<label>Username</label>
                <input type="text" placeholder="Username" name='username' id='username' class="large-12" />
                <label>Password</label>
                <input type="password" placeholder="Password" name="password" id="password" class="large-12" />
                <input type="button"  class="submit " id='login' name="login" value="Login" /> 
                <a href="#" class=" center" data-reveal-id="forgetPassword">Forgot Password?</a>
        	</fieldset>
        </form>
        <!--<div id="forgetPassword" class="reveal-modal small" data-animation="fade">
 <h4>Password recovery window,<small> Enter your email to recover your password</small></h4>
 <hr />
    <div id="msgforget"></div>
    <input type="text" id="memail" name="memail" autocomplete='off' required='required' />
    <button class="button" id="forget" name="forget">Recover</button>
   <a class="close-reveal-modal">&#215;</a>
  </div>-->
        
    </div>
 </div>
 

    	  

	
   
    </div><!--main-->

	<div id="footer">
		<div class="wrapper">
			<p>&copy; 2013 <b>Robert Johnson Holdings</b></p>
		</div><!--wrapper-->
	</div><!--footer-->
    <!-- /.container -->
    

</div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="public/js/jquery-1.7.2.min.js"></script>
        
    <script type="text/javascript">
		$(document).ready(function(e) {
        $("#login").click(function(){
            $.ajax({url:'?url=login/doClientLogin',type:"POST",data:{username:$('#username').val(), password:$("#password").val()},
                success: function(result){
                    logmein(parseInt(result)) 
                },error: function(){
                   
                }
            })
        })
        
        $("#forget").click(function(){
            $.ajax({url:"?url=login/validateEmail", type:"POST", data:{memail:$("#memail").val()},
                success: function(result){
                    $("#msgforget").html(result)
                }
            })
        })
    });
	
	
	function logmein(data){
        if(data===1){
						window.location.href = ("?url=dashboard/index");
                        //window.location = "?url=dashboard/index"
                    }
                    if(data===2){
                        $("#alertme").html("<div data-alert class='alert-box alert'>Invalid username and password combination<a href='#' class='close'>&times;</a></div>");
                    }
    }
		
		
	</script>
  </body>
</html>




