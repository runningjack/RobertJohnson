<?php 
$uri = new Url("");
 ?>
 <!DOCTYPE html>
<!--[if IE 8]> 				 <html class="no-js lt-ie9" lang="en" > <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en" > <!--<![endif]-->

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="initial-scale=1.0, width=device-width" />
<link href="public/css/style2.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css"/>
 <script type="text/javascript" src="public/js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="public/js/bootstrap.min.js"></script>

<style>
	@import url("public/css/resp.css") all and (max-width: 640px);
	#hideme{
		display:none;
		}
</style><link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/pure/0.3.0/pure-min.css"/>
<title>Robert Johnson Holdings</title>
</head>

<body>
	<div id="header">
		<div class="wrapper">
			<img src="public/images/logo_2.png"/>

			<div class="right">
				<div class="welcome">
					<img src="public/images/user.png" alt=""/>
					Welcome, <b>admin</b>! | <a href="<?php echo $uri->link("dashboard/doLogout") ?>">Logout</a>
				</div><!--welcome-->

			</div><!--right-->
		</div><!--wrapper-->
	</div><!--header-->

	<div id="menu">
    
		<div class="wrapper">
        
			<ul>
				<li><a href="<?php echo $uri->link("dashboard/index") ?>">Dashboard</a></li>
				<li><a href="<?php echo $uri->link("supportticket/index") ?>">Support</a></li>
				<li><a href="<?php echo $uri->link("supportticket/create") ?>">Open Ticket</a></li>
				<li><a href="<?php echo $uri->link("services/index") ?>">My Products &amp; Services</a></li>
                <li><a href="<?php echo $uri->link("account/index")?>">Account</a></li>
				<li><a href="<?php echo $uri->link("account/edit")?>">Modify Profile</a></li>
                <li><a href="<?php echo $uri->link("account/changepassword") ?>">Change Password</a></li>
				<li><a href="<?php echo $uri->link("dashboard/doLogout") ?>">Log Out</a></li>
			</ul>
		</div><!--wrapper-->
	</div><!--menu-->

	<div id="main">