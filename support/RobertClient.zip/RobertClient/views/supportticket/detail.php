<div id="main">
		<div class="wrapper">

			<div class="container">
			  <div class="heading">
				<h2>Add New </h2>

					<div class="button">
						<ul>
							<li><a href="<?php $uri->link("supportticket/index") ?>">&laquo; Back To Listing</a></li>
						</ul>
					</div><!--button-->
				</div><!--heading-->
				                
     
     <?php echo $this->myReplyData; ?>
     
        
            </div><!--container-->
		</div><!--wrapper-->
	</div>