<div id="main">
		<div class="wrapper">

			<div class="container">
			  <div class="heading">
				<h2>Add New </h2>

					<div class="button">
						<ul>
							<li><a href="#">« Back To Listing</a></li>
						</ul>
					</div><!--button-->
				</div><!--heading-->

				                
		<form action="<?php echo $uri->link("supportticket/doCreate") ?>" method="post" enctype="multipart/form-data" name="frmEmp" id="frmEmp">
	     <fieldset><div id="transalert"></div>
   	       <legend><h3>Open Ticket</h3></legend>
	            <table width="100%" border="0">
		              <tr>
		                <td width="39%">
		                    <label>Name</label>
		                  
		                    <input type="text"  name="cname"  />
	                      </td>
		                <td width="20%"><label>Phone <span class="red">*</span></label>
	                      
		                    <input type="text"   name="phone"  /></td>
		                <td width="41%">
		                  
		                    <label>Email <span class="red">*</span></label>
	                      
		                    <input type="email"   name="email"  />
		                    <div id="tm2"></div>
	                      </td>
                  </tr>
		              <tr>
		                <td colspan="3">
		                  
		                    <label>Subject <span class="red">*</span></label>
	                      
		                    <input type="text"   name="subject"  />
		                    <div id="tm3"></div>
	                      </td>
                  </tr>
		              <tr>
		                <td>
		                  
		                    <label>Department <span class="red">*</span></label>
	                      
		                    <select id="dept" name="dept">
                          	<option value="Support">Technical Support</option>
                            <option value="Sales">Sales </option>
                            <option value="Billing">Billing</option>
                            <option value="Security">Security</option>
                           </select>
		                    <div id="tm4"></div>
	                      </td>
		                <td>
		                  <label> Priority Level</label>
		                    
	                      
		                    <select id="plevel" name="plevel">
                          	<option value="Medium">Medium</option>
                            <option value="High">High</option>
                            <option value="Low">Low</option>
                           </select>
		                    <div id="tm6"></div>
	                      </td>
		                <td>
		                  
		                   <label>Related Product/Service <span class="red">*</span></label>
	                     
		                   <select id="service" name="service">
                          	<?php
						
				$products = Cproduct::find_by_client($_SESSION['client_ident']);
				foreach($products as $prod){
					echo "<option value='$prod->id _ $prod->prod_name'>$prod->id; $prod->prod_name</option>";
				}
			?>
                           </select>
		                    <div id="tm5"></div></td>
                  </tr>
		              <tr>
		                <td>&nbsp;</td>
		                <td>&nbsp;</td>
		                <td>&nbsp;</td>
                  </tr>
		              <tr>
		                <td>Issue</td>
		                <td>&nbsp;</td>
		                <td>&nbsp;</td>
                  </tr>
		              <tr>
		                <td colspan="3"><textarea  name="issue" ></textarea></td>
                  </tr>
		              <tr>
		                <td><label for="fupload">Attach file</label>
                        <input type="file" name="fupload" id="fupload"></td>
		                <td>&nbsp;</td>
		                <td>&nbsp;</td>
                  </tr>
		              <tr>
		                <td>&nbsp;</td>
		                <td><input type="submit" value="Submit"></td>
		                <td></td>
                  </tr>
           </table>
          </fieldset>
           </form>

	      	 




			</div><!--container-->
		</div><!--wrapper-->
	</div>