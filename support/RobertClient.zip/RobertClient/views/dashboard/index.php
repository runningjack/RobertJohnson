<div class="main">
	<div class="wrapper">

				<div class="block">
					<ul class="tabs">
						<li class="role"><a href="<?php echo $uri->link("supportticket/index") ?>">support ticket</a></li>
						<li class="users"><a href="role.html">Users</a></li>
						<li class="depts"><a href="role.html">Departments</a></li>
						<li class="stock"><a href="role.html">Stock Items</a></li>
						<li class="employee"><a href="role.html">Employee</a></li>
						<li class="vendors"><a href="role.html">Vendors</a></li>
						<li class="stocking"><a href="role.html">Stocking</a></li>
						<li class="product_cats"><a href="role.html">Product Cats</a></li>
						<li class="products"><a href="role.html">Products</a></li>
						<li class="clients"><a href="role.html">Clients</a></li>
					</ul>
				</div><!--block-->

			<div class="small_container">
				
				<div class="block">
					<div class="smaller_heading">
					<h2>User Management</h2>
					</div><!--heading-->
					<div class="content">
						<p>A database index is a data structure that improves the speed of data retrieval operations on a database table at the cost of additional writes and the use of more storage space to maintain the extra copy of data. Indexes are used to quickly locate data without having to search every row in a database table every time a database table is accessed. Indexes can be created using one or more columns of a database table, providing the basis for both rapid random lookups and efficient access of ordered records. In a relational database, indexes are used to quickly and efficiently provide the exact location of the corresponding data. An index is a copy of select columns of data from a table that can be searched very efficiently that also includes a low level disk block address or direct link to the complete row of data it was copied from.</p>

						<p>Some databases extend the power of indexing by allowing indices to be created on functions or expressions. For example, an index could be created on upper(last_name), which would only store the upper case versions of the last_name field in the index. Another option sometimes supported is the use of "filtered" indices, where index entries are created only for those records that satisfy some conditional expression. A further aspect of flexibility is to permit indexing on user-defined functions, as well as expressions formed from an assortment of built-in functions.</p>
					</div><!--content-->
				</div><!--block-->

			</div><!--wider_container-->
			<div class="small_sidebar">
					<ul class="panel">
						<li><a href="#">Item 1</a></li>
						<li><a href="#">Item 1</a></li>
						<li><a href="#">Item 1</a></li>
						<li><a href="#">Item 1</a></li>
						<li><a href="#">Item 1</a></li>
						<li><a href="#">Item 1</a></li>
					</ul>
			</div><!--small_sidebar-->

			<div class="clear"></div>
		</div>
</div>