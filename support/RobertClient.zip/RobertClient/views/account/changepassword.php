<div class="wrapper">

			<div class="container">
				<div class="heading">
				<h2>Change Password</h2>

					<div class="button">
						<ul>
							<!--
<li><a href="#">� Back To Listing</a></li>
-->
						</ul>
					</div><!--button-->
				</div><!--heading-->

				

				<div  id="changepass">
		       	    
			    <form action="<?php echo $uri->link("account/doUpdate") ?>" method="post" name="frmEmp" id="frmEmp">
                <fieldset>
                <div class="transalert"></div>
                <legend>Change Password</legend>
				  <div class="row">
				    <div class="right-label">
				    <label>Username</label>
				    </div>
				    <div>
				    <input class="col-6" rel="catchable" name="uname" id="uname" type="text" value="<?php echo $this->myaccount->username ?>" />
				    </div>
				  </div>
				  
				  
                  <div class="row">
				    <div class="right-label">
				    <label>Old Password <span class="red">*</span></label>
				    </div>
				    <div>
				    <input class="col-6" required="required" rel="catchable" name="opword" id="opword" type="password" value="<?php echo $this->myaccount->password ?>" />
				    <div id="tm"></div>
				    </div>
				  </div>
                  
				  <div class="row">
				    <div class="right-label">
				    <label>New password <span class="red">*</span></label>
				    </div>
				    <div>
				    <input class="col-6" required="required" rel="catchable" name="pword" id="pword" type="password" value="" />
				    <div id="tm"></div>
				    </div>
				  </div>
				  
				  				  
				  <div class="row">
				    <div class="right-label">
				    <label>Re-enter New Password<span class="red">*</span></label>
				    </div>
				    <div>
				    <input  class="col-6" name="pword2" id="pword2" type="password" rel="catchable" value="" />
				    <div id="costp"></div>
				    </div>
				  </div>
				  
				   
				  
				  			  
				  

				    <div class="row">
				    
				   
				          <input name="task" id="task" value="" type="hidden" />
				          <input name="pgid" id="pgid" value="" type="hidden" />
				        
				       <a href="#" class="btn btn-primary" name="pwsave" rel="catchable"  id="pwsave" > Save</a>
				          	 </div>   
                               </fieldset> 
				        </form>

		      	 
</div>



			</div><!--container-->
		</div>