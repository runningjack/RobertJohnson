<?php
define('DIR_SYSTEM', 'C:\wamp\www\RobertClient/system/');
define('DIR_PUBLIC','C:\wamp\www\RobertClient/public/');
define('DIR_FOLDERS_HTTP',"http://localhost/RobertClient/public/");
define("MESSAGE","");
?>