<?php
	class Services extends Controller{
	   public function __construct(){
	       parent::__construct();
       }
       
      public function index($mid=1){
		$servicelist ="";
		if(empty($mid)){
			redirect_to($this->uri->link("error/index"));
			exit;
		}
		$this->loadModel("Services");
		$datum = $this->model->getList("","Services");
		$this->view->myservices =$datum['myservices'];
        $uri = new Url("");
        $servicelist .="<table  width='100%'>
<thead><tr>
	<th>S/N</th><th>ID</th><th>Product</th><th>Serial No</th><th>Location</th><th>Date Installed </th><th></th><th></th>
</tr>
</thead>
<tbody>";

  if($this->view->myservices){
	  $x =1;
    foreach($this->view->myservices as $service){
    $servicelist .="<tr>
    	<td>$x</td><td>$service->prod_id</td><td>$service->prod_name </td><td>$service->prod_serial</td><td>$service->install_address</td><td>$service->sign_off_date</td><td><a href='".$uri->link("services/detail/".$service->id."")."'></a></td>
    </tr>";
	$x++;
    }
  }else{
    $servicelist .= "<tr><td colspan='7'>No record to display</td></tr>";
  }

$servicelist .= "</tbody>
</table>";

$this->view->myservs = $servicelist;
		$this->view->render("services/index");
	}
}
?>