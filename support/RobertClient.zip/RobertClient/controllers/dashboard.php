<?php
class Dashboard extends Controller{
	function __construct(){
		parent::__construct();
		global $session;
		/*if(!$session->client_logged_in()){
			redirect_to($this->uri->link("login/index"));
		}else{
		  $this->index();
		}*/
	}
	/*---------------------------------
	At this point index is the login page
	*---------------------------------*/
	public function index(){
		@$this->loadModel("Dashboard");
		$this->view->render("dashboard/index");
	}
	
	public function doLogout(){
		//@$session = new Session();
		global $session;
		$session->logout();
       	redirect_to($this->uri->link("login/index"));
		//$this->view->render("dashboard/index");
	}
}
?>